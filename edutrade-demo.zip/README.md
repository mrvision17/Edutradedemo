# EduTrade Demo

A simple educational trading simulator using fake money.

## Run locally
Open `index.html` in a browser.

## Deploy with GitHub Pages
1. Create a GitHub repository.
2. Upload `index.html`.
3. Open **Settings → Pages**.
4. Select **Deploy from a branch**.
5. Choose the `main` branch and `/ (root)`.
6. Save and wait for GitHub Pages to publish.

This project is a simulation only. It does not process real money or real trades.
